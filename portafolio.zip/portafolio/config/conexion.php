<?php
function Sesión_start() {
    session_start();
}

function Conexión() {
    $con = new mysqli("localhost", "usuario", "contraseña", "base_de_datos");
    if ($con->connect_error) {
        die("Conexión fallida: " . $con->connect_error);
    }
    return $con;
}

function Set_names() {
    return 'SET NAMES utf8';
}

function Ruta() {
    return dirname(__FILE__);
}
?>
