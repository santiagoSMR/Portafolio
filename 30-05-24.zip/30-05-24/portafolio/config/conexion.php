<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'login_system';

$conexion = new mysqli($host, $user, $pass, $db);

if ($conexion->connect_error) {
    die("Connection failed: " . $conexion->connect_error);
}
?>
